package com.team980.thunderscout.bluetooth;

public class BluetoothInfo {

    /**
     * Unique to the ThunderScout app
     */
    public static final String UUID = "60bec31a-4329-4724-8bee-4d8caab0d5cb";

    public static final String SERVICE_NAME = "ThunderScout";
}
