package com.team980.thunderscout.data.enumeration;

public enum ScalingStats {

    NONE,
    PARTIAL,
    FULL;
}
